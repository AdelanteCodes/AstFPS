* Fixed crash on NeoForge
